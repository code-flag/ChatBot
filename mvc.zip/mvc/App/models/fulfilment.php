<?php

/**
 * 
 */
class Fulfilment extends DataBase
{
	
	function __construct(argument)
	{
		# code...
	}
	protected function apiCall();
	protected function webhook();
	protected function fetch_data();
	protected function train_chat();
	protected function push_data();
	protected function pull_data();
	protected function changeIdentity();
	protected function createAgent();
	protected function login();
	protected function register();
	protected function trainModel();
	protected function getFaq();
	public function response($msg){
		//	reply the chat
		//	
	}

	/*
		this section of code is for response fulfilment
	*/

		protected function response();







	/*
		this section of code is for request fulfilment
	*/















	/*
		this portion of code is for commands calls fulfilment
	*/
	protected function command($command, $cmdInput, $msg){
		if($command === "registration")
		{
			saveCmdInfo($cmd, $cmdInput, $cmdValue);
			sendNextReq($command);
		}
		if($command === "login")
		{
			
		}
		if($command === "trainModel")
		{
			
		}
		if($command === "AddEntity")
		{
			
		}
		if($command === "AddClass")
		{
			
		}
		if($command === "testModel")
		{
			
		}
	}

	public function executeData($command)
	{
		$data = $this->getData($command);
		pushToDb($command, $data);
		restoreQvalue($command);
	}

	protected function getData($command){
		if (file_exists($filename )) {
			//Retrieve the data from our text file.
				$fileContents = file_get_contents($filename);
				//Convert the JSON string back into an array.
				$decoded = json_decode($fileContents, true);
				return $decoded;
			}
			else{
				return 0;
			}

	}

	protected function pushToDb($command, $data)
	{
		if ($command = "registration") {
			$this->signUp($data);
		}
		else if ($command = "login") {
			$this->signIn($data);
		}
		else if ($command = "trainModel") {
			$this->signIn($data);
		}
		else if ($command = "CreateReg") {
			$this->createTable($data);
		}
		else if ($command = "DbInfo") {
			$this->dbInfo($data);
		}
	}


	protected function saveCmdInfo($cmd, $cmdInput, $cmdValue) 
	{
		$filename = $cmd.".txt";
		if ($cmdValue != " ") 
		{
			$newData = array("$cmdInput"=>"$cmdValue");

			if (file_exists($filename )) {
			//Retrieve the data from our text file.
				$fileContents = file_get_contents($filename);
				//Convert the JSON string back into an array.
				$decoded = json_decode($fileContents, true);

				$newfile = array_push($decoded, $newData);
			}
			
			

			$encodedFile = json_encode($newfile);
			
			//Save the JSON string to a text file.
			file_put_contents($filename, $encodedFile);

			updateQuestion($cmd, $cmdInput);
		}

		
		
	}

	public function sendNextReq($cmd)
	{
		$filename = $cmd."_question.txt";
		$cmdFile = getCmdFile($cmd);
		$cmdInput = array_keys($cmdFile);
		$totalInput = count($cmdInput);


		for ($i=0; $i < $totalInput; $i++) { 
			$cmdIn =  $cmdInput[$i];
			if($cmdFile[$cmdIn] == 0)
			{
				$input = "What is your <br>".$cmdIn;
				respond($input);
			}
			break;
		}
	}

	public function restoreQvalue($cmd)
	{
		$filename = $cmd."_question.txt";

		$cmdFile = getCmdFile($cmd);
		$cmdInput = array_keys($cmdFile);
		$totalInput = count($cmdInput);


		for ($i=0; $i < $totalInput; $i++) { 
			$cmdIn =  $cmdInput[$i];
			$cmdFile[$cmdIn] = 0; 
		}

		$encodedFile = json_encode($cmdFile);
			
			//Save the JSON string to a text file.
		file_put_contents($filename, $encodedFile);
	}
	
	public function getCmdFile($cmd)
	{
		//Retrieve the data from our text file.
		$filename = $cmd."_question.txt";
		$fileContents = file_get_contents($filename);

		//Convert the JSON string back into an array.
		$decoded = json_decode($fileContents, true);
		return $decoded; //return the array file
	}
}

?>