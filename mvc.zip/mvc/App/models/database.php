<?php

class DataBase {
	protected function createDb();
	protected function createTable();
	protected function createAgent();
	protected function UpdateDb();
	protected function intentCall();
	protected function dbInfo();
	protected function tableInfo();
	protected function specialKeys();
	function getDesc()
{
	// check class table and description column and choose the most match faqs answer
}
function returnAnswer(){
	
}

public function getFaq($msg, $entity)
	{
		// get phrase
			$phrase = getPhrase();
		// look up phrase db to get relevant intent
		// if percentage of intent discover is low
		// check the category file for best intent
		// if found
		// get faq from db using the best description base on entity and phrase
		// pass to a $faqAns variable to pass to response

	}

	protected function select($sql, $param = []){
		$pds=$pdo->prepare($sql);
		$pds->execute($param);
	}
	protected function uSelect($sql){
		//$sql="SELECT ... FROM ... ...";
		$pds=$pdo->query($sql);
	}

	
	protected function register($tableName, $param = []){

	}
	protected function login($userEmail, $userPassword){

	}
	protected function signUp($param = []){
	
	}
	protected function 
}

?>