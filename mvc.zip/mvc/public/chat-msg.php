<?php
	
	echo "this is from php";

?>