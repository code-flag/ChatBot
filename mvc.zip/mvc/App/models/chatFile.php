<?php
	
	/**
	 * 
	 */
	class chatFile
	{
		protected	$chatData;
		protected	$newMsg;
		protected	$msgOwner;
		protected	$msgTime;
		function __construct()
		{
			# code...
		}
		public function createChatFile()
		{
			$filename = "chats.json";
			$chats = array(array('Time','Who','Message'));

			if (file_exists($filename)) {
				# code...
				echo "$filename text file already exist";
			}
			else{
				if (!is_null($chats)) {
					$encodedString = json_encode($chats);

				//Save the JSON string to a text file.
				file_put_contents($filename, $encodedString);
				}
				
			}

		}


		public function getChatFile($filename)
		{
			$getdata = file_get_contents($filename);

			//Convert the JSON string back into an array.
			$data = json_decode($getdata, true);
			$this->chatData = $data;
			return $data; //return array
		}

		protected function saveChatFile()
		{
			$filename = "chats.json";
			$chats = $this->appendMsg();

			// print_r($chats);
			if (!is_null($chats)){
				$encodedString = json_encode($chats);
				//Save the JSON string to a text file.
				@file_put_contents($filename, $encodedString);
			}
			

		}


		private function appendMsg()
		{
			$file = $this->chatData;
			$msg = $this->newMsg;
			$owner = $this->msgOwner;
			$time = $this->msgTime;
				$arr1 = array("$time"=>array($owner,$msg));

			if (is_null($file)) {
				return $arr1;
			}
			else { 
				$arr2 =  $file + $arr1 ;
				return $arr2;
			}
			

		}

	}


?>