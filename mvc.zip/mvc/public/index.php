<?php
ini_set('display_errors', 0);
require_once '../App/init.php';

$app = new App();


?>