<?php
 /**
  * 
  */
 class Response extends AnotherClass
 {
 	
 	function __construct(argument)
 	{
 		# code...
 	}

 	function injet();
 	function injetJoke();
 	function greetings();

 		function compliment($msg){
		//check the message if its just greetings
		// get greetings file for greeting words
		$grt = getCompliment();

		$gWord = explode(" ", $msg);

		$grtCount = count($grt);
		for ($i=0; $i <$grtCount ; $i++) { 
			# code...
			if ($gWord[$i] == $grt[$i]) {
				# code...
				$found += 1;
			}
			if($gWord[0] == "hi")
			{
				$greet = true;
				$reply = "hello, compliment of the day";
			}
			if($gWord[0] == "hey")
			{
				$greet = true;
				$reply = "Hello. how may i help you";
			}
			if($gWord[0] == "hello")
			{
				$greet[0] = true;
				$reply = "Hi.";
			}
			if($gWord[0] == "how" && $gWord[1] == "far")
			{
				$greet[0] = true;
				$reply = "Nothing much dear. How can i be of help to you";
			}
			if($gWord[0] == "whatsup")
			{
				$greet[0] = true;
			}
			if($gWord == "good day")
			{
				$greet = true;
			}
			if($gWord[0] == "good" && ($gWord[1] == "morning" || $gWord[1] == "afternoon" || $gWord[1] == "evening" || $gWord[1] == "day"))
			{
				$greet = true;
					# code...
				
			}
		}

}


	public function rephraseText($text)
{

	$rephrase = array(
				'i' => "you",
				'my' => "your",
				'mine' => "yours",
				'are we' => "you are",
				'we are' => "you are",
				'we' => "you",
				'me' => "you",
				'our' => "your",
				'ourself' => "yourself",
				'myself' => "yourself",
				'oneself' => "yourself",
				'ourselves' => "yourself",
				'your' => "our",
				'your' => "my",
				'yours' => "mine",
				'you' => "i",
				'you are' => "i am"
			);
	$textCount = str_word_count($text);
	$phraseKey = array_keys($rephrase);
	$phraseCount = count($rephrase);
	for ($i=0; $i < $textCount ; $i++) { 
		# code...check if for the pronoun and replace
		
		for ($j=0; $j < $phraseCount; $j++) { 
			if($text[$i] == $phraseKey[$j])
			{
				$text[$i] == $rephrase[$j];
			}
		}
	}
	$text = implode($text, " ");
	$this->msg = $text."?";
	return $this->msg;
}


 }
?>