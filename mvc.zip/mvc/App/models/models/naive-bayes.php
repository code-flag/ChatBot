<?php
	
	class NaiveBayesClassifier {
		static protected A;
		static protected B;
		function pA_B();
		function pB_A();
		function pA();
		function pB();
		function categorize($data, $category);
		function stopWord($text);
		function stemming($text);
		function lematization($text);
		function train($sample, $label);
		function read_csv($csv_file);
		function getFileType($data);
		function getData($data);
		function classify($data);
		function showResult($result);
		function predict($data){
			// check previous data request with keyword to make prediction
			//getContext();
			//if prediction is not ascertain run the main bayes model
		}
		function updateData($data);
		function getContext($data);
		function decide($result);
		function addEntity($entity, $category[]);
		function result();
		function user_says($data ){
			youSay();
			getPhrase($data);
			getIntent();
			mergeIntent();
		}


	function tokenize(){
	// remove stopwords
	// remove characters
	// return aray

	$this->text = $this->check_inputCharacter($this->text);
	$stopW = $this->getStopWord();
	$stopWCount = count($stopW);
	$textCount = str_word_count($this->$text);  // get the total number of word in text
	$text =  str_word_count($this->$text, 1);	// convert the text to arary of word

	for ($m=0; $m < $textCount ; $m++) { 
		for ($n=0; $n <$stopWCount ; $n++) { 
			if($text[$m] == $stopW[$n] )
			{
				$text[$m] = " ";
			}
		}
	}

	$text = implode($text, " "); // convert to string
	return $this->text = $text;
}

	
	function getClass(){
		//parse entity to check
		// check each class for entity
		// record the number of entity in class into array by class name
		//return the array of class entity with value
	}

	function compareClass(){
	//parsed array class entity value
	// divide with total number of entity
	// get the highest value
	//return the highest class

	// if 2 or 3 is equal ask question again to know about the class
	// then get additional intent and run the class again
    }


    
	}
?>