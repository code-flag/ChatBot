<?php

	class FileOrigin {
		public function __Constructor()
		{

		}
		public function createDictionary(){
			$synonyms = array(
			'd' => "the",
			'u' => "you",
			'ur' => "your",
			'dat' => "that",
			'4' => "for",
			'2' => "to",
			'yeah' => "yes",
			'yea' => "yes",
			'nd' => "and",
			'n' => "and",
			'nt' => "not",
			'dd' => "did",
			'brb' => "be right back",
			'luv' => "love",
			'grt' => "great",
			'pls' => "please",
			'thnks' => "thanks",
			'tanks' => "thanks",
			'tank' => "thank",
			'bt' => "but",
			'2u' => "to you",
			'dnt' => "don't",
			'dt' => "that",
			'cnt' => "can't",

			'students' => "student",
			'studnt' => "student",
			'hotel' => "hostel",
			'hostel' => "hostel",
			'academics' => "academic",
			'acada' => "academics",
			'sch' => "school",
			'skul' => "school",
			'admissions' => "admission",
			'admision' => "admission",
			'admisions' => "admission",
			'admition' => "admission",
			'info' => "information",
			'issues' => "issue",
			'prob' => "problem",
			'accoding' => "according",
			'moni' => "morning",
			'morng' => "morning",
			'msg' => "message",
			'am' => "morning",
			'pm' => "evening",
			'frnd' => "friend",
			'frd' => "friend",
			'convo' => "convocation",
			'synopsis' => "outline"
		);

			if (file_exists('dictionary.json')) {
				# code...
				echo "class.text file already exist";
			}
			else{
				$encodedString = json_encode($synonyms);
				//Save the JSON string to a text file.
				file_put_contents('dictionary.json', $encodedString);
			}
	}

public function createCompliment(){
	
		$filename = "compliment.json";

			$compliment = array(
			'hi' => "Hello",
			'hello' => "Hi",
			'good morning' => "Good morning",
			'good evening' => "Good evening",
			'good day' => "Good day",
			'hello good morning' => "Hi. Good morning how are you doing today",
			'hello good evening' => "Good evening hope you doing well",
			'hello good afternoon' => "Hi. Afternoon",
			'yes' => "okay",
			'yeah' => "okay",
			'yea' => "okay",
			'k' => "okay",
			'ok' => "okay",
			'okay' => "okay",
			'how are you' => "fine, thank you",
			'thank you' => "You are welcome",
			'pardon' => "Please can reframe you request.",
			'i don\'t understand' => "Pls can you reframe your question for me. Please.",
			'bye' => "Nice chatting you. Have a nice day.",
			'do you understand me' => "yes"
			
		);

			if (file_exists($filename)) {
				# code...
				echo "$filename file already exist";
			}
			else{
				$encodedString = json_encode($compliment);
				//Save the JSON string to a text file.
				file_put_contents($filename, $encodedString);
			}
	}

public function createStopWord(){
			$synonyms = array(
						"the",
						"you",
						"your",
						"that",
						"for",
						"to",
						"yes",
						"no",
						"on",
						"in",
						"over",
						"under",
						"till",
						"and",
						"too",
						"want",
						"won't",
						"should",
						"would",
						"they",
						"can't",
						"will",
						"is",
						"her",
						"his",
						"did",
						"didn't",
						"cantn't",
						"don't",
						"please",
						"thanks",
						"with",
						"thank",
						"i",
						"want",
						"how",
						"can"
		);

			if (file_exists('stopWord.json') ) {
				# code...
				echo "dictionary.text file already exist";
			}
			else{
				$encodedString = json_encode( $synonyms);
				//Save the JSON string to a text file.
				file_put_contents('stopWord.json', $encodedString);
			}
		}


		public function createPhrase()
		{
			$phrase = array(
				'i want to,',
				'i want,',
				'i want to,',
				'i want you,',
				'i have a,',
				'i have issue,',
				'i need your help,',
				'what can i,',
				'what do you mean,',
				'what is,',
				'what are the,',
				'what time,',
				'what is,',
				'when is,',
				'when will,',
				'how,',
				'how to,',
				'how can i,',
				'how can we,',
				'how many,',
				'how many time,',
				'how do i,',
				'how do you,',
				'how do we,',
				'how will,',
				'how will i,',
				'how will you,',
				'how will it,',
				'the information,',
				'the issue,',
				'the best,',
				'time table,',
				'can i,',
				'can you,',
				'do you,',
				'do i,',
				'maybe,',
				'probably,',
				'possibly,',
				'possible,',
				'why can\'t you,',
				'why can\'t we,',
				'why can\'t i,',
				'according to,',
				'help me with,',	
				'can you tell,',	
				'can you explain,',
				'can you guide,',  
				'can you help me,',
				'Hey fahad,',   
				'hey friend,',
				'hey chatbot how,',
				'please,',
				'please can you,',
				'please can i,',
				'hi,',
				'hey,',
				'hello,',
				'good morning,',
				'good evening,',
				'good day,',
				'good afternoon,',
				'hello sir,',
				'hello ma,',
				'good to hear,',
				'good to see,',
				'how fa,',
				'how your side,',
				
			);

			if (file_exists('phrase.txt')) {
				# code...
				echo "phrase.text file already exist";

			}
			else{
				file_put_contents("phrase.txt",$phrase);
			}
		 	//echo $arr['hello sir'];
		}


	public function createAllPhrase()
		{
			$phrase = 
				'i want to you have a issue need your help can what do is are the time how we many will it information best time table time-table maybe probably possibly possible why can\'t according help me with tell explain guide Hey fahad friend hey chatbot please hi hello good morning evening day afternoon sir ma hear see side';

			if (file_exists('phrase.txt')) {
				# code...
				echo "phrase.text file already exist";

			}
			else{
				file_put_contents("allPhrase.txt", $phrase);
			}
		 	//echo $arr['hello sir'];
		}

		public function createClass()
		{
			$cat_entity = array(
							'School' =>array(
								'school' => 1, 
								'admission' => 0, 
								'department' => 0, 
								'registration' => 0, 
								'hostel' => 0, 
								'exam' => 1
							) ,
							'department' =>array(
								'school' => 1,
								'admission' => 0,
								'department' => 1,
								'registration' => 1,
								'hostel' => 0,
								'exam' => 0
							) ,
							'Admission' =>array(
								'school' => 1,
								'admission' => 0,
								'department' => 1,
								'registration' => 1,
								'hostel' => 0,
								'exam' => 0
							)  
						);

			if (file_exists('class.json')) {
				# code...
				echo "class.text file already exist";
			}
			else{
				$encodedString = json_encode($cat_entity);

				//Save the JSON string to a text file.
				file_put_contents('class.json', $encodedString);
			}

		}

		public function createClassFile()
		{
			$cat_entity = array(
							"i want to" =>array(
								"check result exam time table 100 200 300 400 500 test"=> "result",
								"do registration post utme post-utme out"=> "registration",
								"know number change school course offer"=> "school",
								"post utme result out admission list second first batch"=> "result",
								"first second semester result out"=> "result",
							) , 
							'how can i' =>array(
								'check post utme first second semester result' => "result", 
								'check post utme result' => "result", 
								'pay school fee payment' => "payment",
								'fee do change course' => "school",
								'unable change register login portal password correct' => "school" 
							), 
							"how much" =>array(
								"school fee session how much new "=> "payment",
								"department departmental payment fee"=> "payment",
								"faculty fee sug association"=> "payment"
							) ,
							"how many" =>array(
								"course school offer"=> "school",
								"student admission school"=> "school",
								"faculty department course school"=> "school"
							) , 
							'can you' =>array(
								'tell yourself about' => "personalq", 
								'school tell activity curriculum calender' => "school", 
								'guild do pay school fee' => "payment" 
							), 
							'can i' =>array(
								'know you meet' => "personalq", 
								'what can you do' => "personalq", 
								'pay school fee' => "payment",
								'pay school fee pay payment installmentally' => "payment"
							), 
							"what is" =>array(
								"your name age purpose"=> "personalq",
								"cut off mark course"=> "school",
								"check school course"=> "school"
							) , 
							'what can i' =>array(
								'pending result unable check result' => "result", 
								'pending payment unable' => "payment", 
								'change course' => "school",
								'unable register forgot login portal password correct' => "school" 
							),
							'when is' =>array(
								'deadline payment school portal close fee department faculty acceptance' => "payment", 
								'school resume close' => "school", 
								'exam starting commence' => "school",
								'unable register forgot login portal password correct' => "school" 
							)

						);

			if (file_exists('classFile.json')) {
				# code...
				echo "classFile.json file already exist";
			}
			else{
				$encodedString = json_encode($cat_entity);

				//Save the JSON string to a text file.
				file_put_contents('classFile.json', $encodedString);
			}

		}

		public function createEntity()
		{

			$entity = "school,history,calender,fee,convocation,clearance,details,legacy,over,year,accomplishment,facilities,number,quality,standard,structure,relevance,cgpa,system,affiliates,programs ,course,time table,project,publication,list,payment,pay,lecturer,latest,admission,update,post,utme,predegree,program,undergraduate,postgraduate,master,phd,acceptance,out,result,post,utme,post-utme,score,requirements,merits,register,registration,login,error,hostel,details,room,book,news,preview,chatbot,reports,reviews,observation,queries ,accommodation,details,location,see,sample ,cv,new,social programs,programs,orientations,public,lecture,inauguration,seminar,prerequisite,cut-off,cut,off,minimum,amount,conference,celebrations,sport ,when,where,how,much,venue,time,table,name,exam,test,title ,association,sug,department,student,union,info,excos,outline,semester,session,curriculum,new,happening,address,block,classroom,final,level,100,200,300,400,500,registrar,admin,method,pending,closing,network,unable,check,can,do,want,deadline,means,receipt,date,debit,will,would,yourself,you,tell,know,meet,about,change,password,correct,pend,forgot,start,starting,commence,resume,resumption,second,first,admit,portal,profile,batch,supplementary,departmental";

			if (file_exists('entity.txt')) {
				# code...
				echo "entity.txt file already exist";
			}
			else{
				file_put_contents("entity.txt", $entity);
			}

		}


		public function createPaymentAns()
		{

			$filename = 'payment.json';
			$ans =array( 
				'0' => array('desc','entity','answer'),
				'1' => array('school fee','how,much,fee,school,pay','Every Students are to pay the sum of #1.2m for the session.'),
				'2' => array('school fee','when,closing,close,deadline,final,date,fee,time','School fees payment will be due on 20 May 2021.'),
				'3' => array('school fee','method,means','The method for payment is either through bank or school portal.;To pay through bank,<br>Go to any bank and tell them you wan to pay school fees. They would guild yu through.<br>To pay through school portal,<br>Just login to school website portal and follow the link and pay.;However, you will need MasterCard ATM for this method.'),
				'4' => array('school fee','unable,network,receipt','Sorry for the incovinience you might have been having regards your payment.; The network server might be slow or there is too much trafic on it. kindly be patient and keep trying.'),
				'5' => array('school fee','pending,debit,receipt','Sorry for the problem so far.; kindly take your receipt to school ICT center as a proof.<br> Dont worry it would be rectified.'),
				'6' => array('school fee','how,can,pay,do,would,will,','To pay your school fee, follow the following instruction.;<br>use this link <br>www.bazeuniversity.edu.ng/portal/school-fee<br>;login to using your matric no or jamb reg-no if you are new student.;Navigate to undergraduate and click on the link;In the open page, enter your card details and click proceed;You will receive an OTP code to confirm your payment. enter it and submit.;A reciept would be display for you, print it and keep for reference sake.;That is all.;<br>Is this helpful?'),
				'7' => array('school fee','how,want,pay,can','Do you mean to pay school fee?'),
				'8' => array('acceptance fee','acceptance,fee,how,much','Acceptance fee is #100,000'),
				'9' => array('faculty fee','faculty,fee,how,much','Faculty fee is #10,000'),
				'10' => array('department fee','department,departmental,fee,how,much','Departmental fee is #10,000')
			);

			if (file_exists($filename)) {
				# code...
				echo "$filename file already exist";
			}
			else{
				$encodedString = json_encode($ans);
				//Save the JSON string to a text file.
				file_put_contents($filename, $encodedString);
			}
		}

	public function createSchoolAns()
	{
		$filename = 'school.json';
		$ans = array( 
				'0' => array('admission','post,utme,post-utme,out','answer'),
				'1' => array('admission','admission,list,out,result','answer'),
				'2' => array('admission','admission,batch,first,list','First batch is out... this information was updated Nov 10 2020'),
				'3' => array('admission','admission,batch,second,list','Second batch is out... this information was updated December 15 2020'),
				'4' => array('admission','admission,batch,supplementary,list','Sorry! supplementary list is not available.'),
				'5' => array('course','you,how,many,offer,course','School offer 50 courses'),
				'6' => array('resumption','resume,resumption,date,when,what','No information yet'),
				'7' => array('calender','how,can,calender','Kindly check school website.'),
				'8' => array('department','department','No information yet')
			);
		if (file_exists($filename)) {
				# code...
				echo "$filename file already exist";
			}
			else{
				$encodedString = json_encode($ans);
				//Save the JSON string to a text file.
				file_put_contents($filename, $encodedString);
			}
	}

	public function createResultAns()
	{
		$filename = 'result.json';
		$ans = array( 
				
				'0' => array('desc','entity','answer'),
				'1' => array('school','school,result,out,online','Last semester result is out'),
				'2' => array('100L result','100,level,result,out','100 Level result is always out 2 weeks after exam. Try check your student portal'),
				'3' => array('200L result','200,level,result,out','200 Level result is always out 1 month after exam. Try check your student portal'),
				'4' => array('300L result','300,level,result,out','300 Level result is always out 1 month after exam. Try check your student portal'),
				'5' => array('400L result','400,level,result,out','400 Level result is always out 1 month after exam. Try check your student portal'),
				'6' => array('500L result','500,level,result,out','500 Level result is always out 1 month after exam. Try check your student portal'),
				'7' => array('utme','post,utme,post-utme,result','Sorry, there is no update for now')
			);
		if (file_exists($filename)) {
				# code...
				echo "$filename file already exist";
			}
			else{
				$encodedString = json_encode($ans);
				//Save the JSON string to a text file.
				file_put_contents($filename, $encodedString);
			}
	}


	public function createPersonalAns()
	{
		$filename = 'personalq.json';
		$ans = array( 
				'0' => array('desc','entity','answer'),
				'1' => array('name identity','what,name','I am Fahad.'),
				'2' => array('profile','can,who,tell,about,yourself,describe','My name is Fahad, student assistant and Baze University Bot.; My creator is Fahad from baze university.;I was created March 2021.; My duty is to help student with any information about school and also to make collection of student data easier for any purpose. I do this by getting user data from chats, bypassing the usual sign-up form which is too hectic for many students.'),
				'3' => array('purpose','what,can,you,do,offer','My duty is to help student with any information about school and also to make collection of student data easier for any purpose.'),
				'4' => array('age','how,old','less than a year old.')
			);
		if (file_exists($filename)) {
				# code...
				echo "$filename file already exist";
			}
			else{
				$encodedString = json_encode($ans);
				//Save the JSON string to a text file.
				file_put_contents($filename, $encodedString);
			}
	}

	public function createRegistrationAns()
	{
		$filename = 'register.json';
		$ans = array( 
				'0' => array('desc','entity','answer'),
			);
		if (file_exists($filename)) {
				# code...
				echo "$filename file already exist";
			}
			else{
				$encodedString = json_encode($ans);
				//Save the JSON string to a text file.
				file_put_contents($filename, $encodedString);
			}
	}

	public function createAdmissionAns()
	{
		$filename = 'admission.json';
		$ans = array( 
				'0' => array('desc','entity','answer'),
			);
		if (file_exists($filename)) {
				# code...
				echo "$filename file already exist";
			}
			else{
				$encodedString = json_encode($ans);
				//Save the JSON string to a text file.
				file_put_contents($filename, $encodedString);
			}
	}












	}




?>