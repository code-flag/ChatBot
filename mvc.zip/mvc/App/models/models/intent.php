<?php
class Intent extends UserSay
{
	public  $result;
	public $data;
	public $tempData;
	public $tempFile;
	public $faq = " ";
	public $entity=" ";
	public $prevMsgType="";

	public function listen($msg)
	{
		if ($this->checkCommand() === 'command') {
			# code...
			$msg = tokenize($msg);
			$cmdType = getCommandType();
			$cmdInput = getInputType();
			$this->fulfilCommand($cmdType, $cmdInput, $msg);
		}
		else{
			$this->setData($msg);
			$this->checkMsg();
			$this->fulfilment();
		}
	}
	
	
		private function fulfilment(){

		// $fulfil = new Fulfilment()
		$this->prevMsgType = getCommand();
		$this->getClassFaq($this->msg);

		if ($this->msgType === "command" && $this->prevMsgType !=='command') 
		{
			$this->saveMsgType();
			$this->saveCommand();
			$this->command($this->argument, [0]);
		}
		else if ($this->msgType === "command" && $this->prevMsgType ==='command')
		{
			$msg = "Hey! your command was understood. kindly respond to my request accordingly";
			$this->response($msg);
		}
		else if ($this->msgType === "greeting" && $this->prevMsgType !=='command')
		{
			$this->response($this->argument);
		}
		else if ($this->prevMsgType !=='command' && $this->msgType === "request") 
		{
			$this->getFaq($this->faq,$this->entity);
		}
		else if ($this->prevMsgType ==='command' && $this->msgType === "request") 
		{
			$this->command($this->prevMsgType,[$this->faq => $this->entity]);
		}	
	}

	private fulfilCommand($cmd, $msg)
	{
		if (getClosingCmd($msg)) {
			executeData($cmd);
			saveMsgType("none");
		}
		else{
			command($cmd, $msg);
		}
		
	}

	public function getClosingCmd($msg)
	{
		$submit = strtolower($msg);
		if ($msg === "submit") {
			return true;
		}
		else{
			return false;
		}
	}

	public function checkCommand()
	{
		$filename = "command.txt";

		if (file_exists($filename)) {
			$fileType = file_get_contents($filename);
			return $fileType;
		}
		else
		{
			return 0;
		}
	}

		public function command($msg,$param = []){
			/*
				
			*/
		}
		public function getFaq($msg){
			/*
				
			*/
		}
		public function response($msg){
			/*
				
			*/
		}


/*
	this function is used to rephrase user msg should incase there is need for asking more question
*/


}

	
function isPrevKnow(){
	
}



function getChatTrend($text = []){
	//get the previous keyword
	//get intent
	//get category
}
function recordIntent($intent)
{
	// record intent keywords
	// record category
	// predict next keyword
}
function intentChats($text)
{
	//this function get all the responses for any chat regards the keywords or entity

	// load dictionary
	$userSays = rUserSays();
	$userSaysKeys = array_keys($userSays);
	$totalWords = count($dictionary);
	$textWords = count($this->text);

	// check by comparision the similar words
	for ($i=0; $i < $textWords ; $i++) 
	{ 
		for ($k=0; $k < $totalWords; $k++) { 
			// search the user say phrase to deduse a meaning
			// if meaning found, check the entity keys in the text
			// if entity found is interpretatable pass the text for classification of faqs
			// else if no key found display the display with the phrase key value.
			if($text[$i] == $userSaysKey[$k]){
				$text[$i] = $userSays[$k]; // assign dictionary value
			}
		}
	}
	
}


/*function getPhrase()
{
	$getPhras = file_get_contents('phrase.txt');
	$phrase = explode(",", $getPhras); // convert the return string to array

	return $phrase; //return array
}

*/
protected function rDictionary()
{
	$fileContents = file_get_contents('dictionary.json');

	//Convert the JSON string back into an array.
	$decoded = json_decode($fileContents, true);
	return $decoded; 
}




function keepText(){
	//save the text to keep track of previous conversation
}
function getPrev()
{
	// get the previous text meaning and and intent then answer
}
function createReg($department, param[])
{
	// trigger registrtion code in fulfilment
	// use department for table name, pass all user data to db
}
function respond(){
	//get what to say from value return from db
	// render or send to chat
}

protected function tokenize(){
	// remove stopwords
	// remove characters
	// return aray

	$msg = check_inputCharacter($this->msg);
	$stopW = getStopWord();
	$stopWCount = count($stopW);
	$textCount = str_word_count($msg);  // get the total number of word in text
	$text =  explode(" ", $msg);	// convert the text to arary of word

	for ($m=0; $m < $textCount ; $m++) { 
		for ($n=0; $n <$stopWCount ; $n++) { 
			if($text[$m] == $stopW[$n] )
			{
				$text[$m] = " ";
			}
		}
	}

	//$text = implode($text, " "); // convert to string
	//echo "$text";
	return $text;
}

protected function check_inputCharacter($data){
	$data= trim($data);
	$data= stripslashes($data);
	$data= htmlspecialchars($data);
	return $data;
	}

	protected function getClassFaq($text)
	{
		//$text= lematize($text); // replace abbrviated words
		$t_phrase = $this->getTextPhrase($text); // get the phrase in a text
		$t_entity = $this->tokenize($text);      // remove all the stopwords and leave alone the entities
		$t_Phrase_count = count($t_entity); // count the number of entity found in the text

		$filename = "classFile.json";		// name of the file that holds data
		$data = $this->getData($filename);			// get the data from directory
		 $totaldata = count($data);			// return the total number of array or row of data in the file data
		 $dataPhrase = array_keys($data); // get phrase keys: first column of the array
		 $prevEnt= 0 ;  $prevEnt2 = 0; $classNo = 0; $classNo2 = 0; $foundPval =""; $foundPval2 ="";
		 $phraseFound = false; $mainEntity=array(); $mainEntity2= array();

		 

		 	for ($k=0; $k < $totaldata ; $k++) {  // loop for no of data phrase in the row

		 		if ($t_phrase == $dataPhrase[$k]) {  //check if phrase found in the text match any of the data phrase
		 			$phraseFound = true;
		 			$foundPval = $t_phrase; // save the phrase
		 			//echo "very true";
		 				$dataEntity = array_keys($data[$dataPhrase[$k]]); // get entity keys in data array
		 				$dataPhraseEnt = count($dataEntity);

		 			for ($i=0; $i <$dataPhraseEnt ; $i++) {     //for each data array phrase
		 				$entity = explode(" ", $dataEntity[$i] );  //convert file entity to array

			 			$val = $this->findEnt($t_entity, $entity);		// check if text entity can be found in data array entity. if found return the number of entity found
			 			if ($prevEnt < $val) {  // check if later is more than previous then there is tendency that later is more likely to be the answer
			 				$prevEnt = $val;
			 				$classNo = $i;
			 				$mainEntity = $entity; // get the main entity
			 			}
			 			
		 			}
		 			//echo "<br> this is it <br>".$data[$dataPhrase[$k]][$dataEntity[$classNo]]."<br>";
		 			// save the faq in a variable
		 			$classFaq1 = $data[$dataPhrase[$k]][$dataEntity[$classNo]];
		 		}
		 		else {
		 			// if the phrase not found in the file data phrase, then check other phrase for like entity
		 			$dataEntity = array_keys($data[$dataPhrase[$k]]); // get entity in array
		 				$dataPhraseEnt = count($dataEntity);

		 			for ($i=0; $i <$dataPhraseEnt ; $i++) { 
		 				$entity2 = explode(" ", $dataEntity[$i] );  //convert file entity to array
			 			$val2 = $this->findEnt($t_entity, $entity2);
			 			if ($prevEnt2 < $val2) {
			 				$prevEnt2 = $val2;
			 				$classNo2 = $i;
			 				$mainEntity2 = $entity2;
			 				$foundPval2 = $dataPhrase[$k];
			 			}
			 			
		 			}

		 			$classFaq2 = $data[$dataPhrase[$k]][$dataEntity[$classNo2]];
		 		}
		 	}

		 	if ($prevEnt < $prevEnt2) { // compare the 2 phrase with highest entity comparison
		 		
		 		if ($phraseFound != false) {  // save the new entity under the new phrase if no one is found
		 			$this->updatePhrase($data, $foundPval, $t_entity, $classFaq2);
		 		}
		 		else{							// else if phrase found
		 			$tp = count($t_entity);
		 			$dp = count($mainEntity2); 
		 			if ($tp > $dp) {			// if text entity of text is more than data phrase entity save text phrase as key
		 				$this->updatePhrase($data, $t_phrase, $t_entity, $classFaq2);
		 			}
		 			else   			// else if text entity is less save the data under the found phrase
		 			{
		 				$this->updatePhrase($data, $foundPval2, $t_entity, $classFaq2);
		 			}
		 		}
		 		return $classFaq2;
		 	}
		 	else  // if found phrase entity is more then run this loop
		 	{
		 		$tp = count($t_entity);
		 		$dp = count($mainEntity);
		 		if ($tp >= $dp) {
		 			$this->updatePhrase($data, $foundPval, $t_entity, $classFaq1);
		 		}
		 		return $classFaq1;
		 	}

	}

	protected function updatePhrase($arr1, $phrase, $entity, $faq)
	{
		$entity = implode(" " , $entity); //convert the array entity to string 

		$arr2 = array($entity => $faq);   // convert entity to key and faq to value
		if(array_key_exists($phrase, $arr1))  // check if the phrase is existing already
		{
			$arr4 = array_merge($arr1[$phrase], $arr2);  //add the entity key with value to phrase key
			$arr4 = array_merge($arr1, array($phrase=>$arr4)); // merge the added array for new entity back to main array as value
			//replace the existing file
			//var_dump($arr4);
			$encodedString = json_encode($arr4);
			//Save the JSON string to a text file.
			//file_put_contents('classFile.json', $encodedString);
		}
		else
		{
			//array_push(array, var);
		}
		
		//var_dump($arr4);
	}

	protected function getTextPhrase($text)
	{
		
		$phrase = $this->getPhrase();
		$totalPhrase = count($phrase);
		//var_dump($phrase);
		//convert the text to array of word
		$totalword = str_word_count($text);  // count the word
		$textW = explode(" ", $text);  // convert to array or words
		$textWord =""; $textPhrase=""; $ct = 0;

		$prevPhraseNo = 0; $foundp = false;

			for ($k=0; $k < $totalPhrase ; $k++) { 
				
				/*
					this loop check if phrase is in a text and if found it get the entity
				*/

				$strC = substr_count($text,$phrase[$k]);
				//echo "<br> found <br> $strC and ct is $ct <br>";
				$pw1 = count(explode(" ", $phrase[$k]));
				
				
				//$pw2 = count(explode(" ", $phrase[$k-1]));
				if($k != 0  && $strC != 0 && $strC >= $ct  && $ct != 0){
					$pw2 = count(explode(" ", $phrase[$prevPhraseNo]));
					if ($pw1 > $pw2 ) {
						# code...
						$textPhrase = $phrase[$k];
						$prevPhraseNo = $k;
						$ct = $strC;
						//echo "<br>value $phrase[$k] is = $pw1 and $pw2 <br>";
					}
					
				}
				else if(($k == 0 || $ct >= 0) && $strC > 0){
					$ct = $strC ;
					if ($ct > 0) {
						$textPhrase = $phrase[$k];
						$prevPhraseNo = $k;
					}
				}
			}
		
		return $textPhrase;
	}



	protected function getPhrase()
	{
		$getPhras = file_get_contents('phrase.txt');
		$phrase = explode(",", $getPhras); // convert the return string to array
		return $phrase; //return array
	}

	
	protected function findEnt($textEnt, $fileEnt)
	{
		$k = count($textEnt);
		$j = count($fileEnt);
		$found = 0;

		for ($i=0; $i < $k; $i++) { 
			for ($m=0; $m < $j ; $m++) { 
				if ($textEnt[$i] == $fileEnt[$m]) {
					$found = $found + 1;
				}
			}
		}
		$occurence = $found;
		$found= 0;
		return $occurence ;

	}


	protected function getData($filename){
		$getdata = file_get_contents($filename);

		//Convert the JSON string back into an array.
		$data = json_decode($getdata, true);
		return $data; //return array
	}




?>