<?php

	class controller 
	{
		public function model($model)
		{
			require_once '../App/models/'.$model.'.php';
			return new $model();
		}

		public function Views($view)
		{
			require_once '../App/views/'.$view.'.php';
		}
	} 

	
?>