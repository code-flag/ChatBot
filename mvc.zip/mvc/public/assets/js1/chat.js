var t_tag; var m_val; var reply=""; var msg = "";
function trigEnter(event)
		{
			//get the keycode for all keyboard using x variable below
			//var x = event.keyCode;
			//$('#test-msg').val(x);

			var m_tag1 ='<div class="space"> <div class="r-msg">';
			var m_tag2 = '</div></div>';
			 m_val  = $('#test-msg').val();
			t_tag  = m_tag1 + m_val + m_tag2; 
			
			if (event.keyCode == 13) {
				//document.getElementById("test-msg").value = "ihki8 u44554" + m_val;
				//document.getElementById("msg-v").value = t-tag;
			}
			else if (event == 5) {
				//$("#msg-v").html(m_val);
				
				/*document.getElementById("msg-v").innerHTML = t_tag;*/
				document.getElementById("msg-button").click();
			}

		}

$("#msg-button").click(function(){

				msg = m_val;
				$('#test-msg').val("");
				$("#msg-v").load("../../chatpage/chat/1", {
							 reply : "submit",
							 message: msg
							 // reciever_id: idGlobal
						}); 

/*
						var fd = new FormData();
						fd.append('message',"msg");
						fd.append('reply', reply);
						$.ajax({
	                    url:'../../chatpage/chat/0',
	                    type:'post',
	                    data:fd,
	                    contentType: false,
	                    processData: false,
	                    success:function(response){
	                        if(response != 0){
	                          // $(".image-preview").html(response);
	                           if(response == "done")
	                           {
	                           	window.location.href = 'profile.php';
	                           }
	                           else
	                           {
	                           		$('#msg-v').html(response);
	                           }
	                        }else{
	                            alert('File not uploaded');
	                        }
	                    }
	                });*/
				 

			});

