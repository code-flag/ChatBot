<!DOCTYPE html>
<html>
<head>
	<title>I am Fahad</title>
	
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="../../../public/assets/css/style.css">
<link rel="stylesheet" href="../../../public/assets/css/template-style.css">

      <link rel="stylesheet" href="../../../public/assets/css/components.css">
      <link rel="stylesheet" href="../../../public/assets/css/responsee.css">
      <link rel="stylesheet" href="../../../public/assets/css/icons.css">

      <link rel="stylesheet" href="../../../public/assets/owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="../../../public/assets/owl-carousel/owl.theme.css">
      <!-- <link rel="stylesheet" href="../../../public/assets/css/icons.css"> -->
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="../../../public/assets/js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="../../../public/assets/js/jquery-ui.min.js"></script>    
      <script type="text/javascript" src="../../../public/assets/js/template-scripts.js"></script> 

</head>
<body>
      <header>
         
         <nav>
            <div class="line">
               <div class="s-12 l-2">
                  <p class="logo"><strong>Baze</strong>Bot</p>
               </div>
               <div class="top-nav s-12 l-10">
                  
                  <ul class="right">
                     <li><a href="../../home/index/0">Home</a></li>
                     <li><a href="#">About BazeBot</a></li>
                     <li><a href="../../home/index/0">Documentation</a></li>
                     <li><a href="../../home/index/0">Features</a></li>
                     <li><a href="../../home/index/0">Contact</a></li>
                  </ul>
               </div>
            </div>
         </nav>
      </header>  

	<section class="chatpage">
		<div class="mainChat">

			<div>
				<div class="chat-head">
					<img src="../../../public/assets/img/profile-pic.jpg">
					<div class="g-icon"> </div> Fahad <br>20 March 2021, 7:15 pm
				</div>
				<div class="page">
					<div class="space">
						<div class="l-msg"> <img src="../../../public/assets/img/profile-pic.jpg">
						Welcome! <br> My name is Fahad, student assistant and Baze University Bot. Feel free to ask me any question regards the school activities and any related information.</div>
					</div>
					
					<span id="msg-v"></span>
					
				</div>

				<div class="msg-input" id="response">

					<textarea  type="text"  name="reply-inbox" id="test-msg"  onkeyup="trigEnter(event)" autocorrect="on"placeholder="type your message" ></textarea> 
							
							 <button class="send" id="msg-button" onclick="trigEnter(5)">Send <i class="icon-arrow_right"></i></button>
				</div>
				
				
				
			</div>
			
		</div>

		<div class="chatBotInfo">
			
			<div class="img-text">
				<img src="../../../public/assets/img/student2.jpg">
				<span class="img-t"> 
					<h1 style="color: #ffcc00;"> The Game Changer </h1>
					Baze University is one of the best University in Nigeria. Baze University is currently implementing machine learning algorithm to enhance chatBot intelligence. 
				</span>
			</div>

			<div class="info">
				<h2>About Us</h2>
                            <div class="tx-div"></div>
                            <p>Baze University delivers quality by having experienced international staff, superb teaching equipment, overseas external examiners, and first-rate buildings to guarantee standards.Baze aims to provide university education to British standards in Nigeria at about half the cost of sending a student to study abroad.</p>
				<h2> About Baze ChatBot</h2>
				<p>
					Baze as successfully built a chatbot that can relate with student and also help them to solve any problem related to their academic. Chatbot can easily chat with student and also understand any information request given to it.
				</p>
				<p>
					Besides, Baze chatbot makes creation of registration easier for any activities in school. With baze chatbot, student can easily supply their information and chatbot will get them registered without going through the stress of filling form.
				</p>
			</div>
		</div>

	</section>
	

	<script src="../../../public/assets/js1/jquery-3.4.1.js"></script>
				<script src="../../../public/assets/js1/chat.js"></script>
				<script type="text/javascript" src="../../../public/assets/js/responsee.js"></script>
      <script type="text/javascript" src="../../../public/assets/owl-carousel/owl.carousel.js"></script>
      <script type="text/javascript">
         jQuery(document).ready(function($) {
            var theme_slider = $("#owl-demo");
            var owl = $('#owl-demo');
            owl.owlCarousel({
              nav: false,
              dots: true,
              items: 1,
              loop: true,
              autoplay: true,
              autoplayTimeout: 6000
            });
            var owl = $('#owl-demo2');
            owl.owlCarousel({
              nav: true,
              dots: false,
              items: 1,
              loop: true,
              navText: ["&#xf007","&#xf006"],
              autoplay: true,
              autoplayTimeout: 4000
            });
        
            // Custom Navigation Events
            $(".next-arrow").click(function() {
                theme_slider.trigger('next.owl');
            })
            $(".prev-arrow").click(function() {
                theme_slider.trigger('prev.owl');
            })     
        }); 
      </script>
</body>
</html>