<?php
	
class UserSay {
	public $msg =" ";
	private $flag = false;
	protected $fag = "";
	protected $msgType ="";
	protected $compliment=" ";
	protected $tempFileData;
	protected $argument="";

	protected function __Contstuctor($msg){

	}

	public function setData($msg)
	{
		$msg = $this->check_inputCharacter($msg);
		$this->lematize($msg);
	}
	protected function rDictionary()
	{
		$fileContents = file_get_contents('dictionary.json');

		//Convert the JSON string back into an array.
		$decoded = json_decode($fileContents, true);
		return $decoded; 
	}


	protected function lematize($msg)
	{
		// load dictionary
		$msg = strtolower($msg);

		$dictionary = $this->rDictionary();
		$dictionaryKeys = array_keys($dictionary);
		$totalWords = count($dictionary);
		//$text = str_word_count($msg, 1);
		$text = explode(" ",$msg);
		//print_r($text);
		$textWords = count($text);
		//echo "$textWords";
		//$finalText ="";

		// check by comparision the similar words
		for ($i=0; $i < $textWords ; $i++) 
		{ 
			for ($k=0; $k < $totalWords; $k++) { 
				// replace the words with expected synonyms or words
				// e.g students with student, k with okay, d with the

				//echo "$dictionaryKeys[$k]";
				if($text[$i] == $dictionaryKeys[$k]){
					$text[$i] = $dictionary[$dictionaryKeys[$k]]; // assign dictionary value
					$val = $dictionaryKeys[$k];
					//echo "found $dictionaryKeys[$k] = $dictionary[$val] <br>";
				}

			}
		}
		$text = implode($text, " ");
		$this->msg = $text;

		//echo "$msg";
	}



	protected function checkMsg(){
	//check if its a command by command function
	//check if its a greeting by compliment function
	//check if its a request by request function
		
		if($this->msg != " ")
		{
			if ( $this->isCommand() ) {
				# code...
				$this->saveCommand();
				$this->command = $this->saveMsgType($this->argument);
				 $this->msgType ="command";
			}
			elseif ($this->isGreeting()) {
				# code...
				 $this->msgType ="greeting";
			}
			elseif($this->isRequest()){
				 $this->msgType ="request";
			}
			else{
				echo "Hey! <br>I don't understand the intent of your message. Kindly ask me relevant issues.<br> Thanks.";
			}
		}

	}

public function saveCommand()
	{
		//Retrieve the data from our text file.
		$filename = "command.txt";
		$fileContents = file_put_contents($filename, "command");
	}
public function saveMsgType($type)
	{
		//Retrieve the data from our text file.
		$filename = "messageType.txt";
		$fileContents = file_put_contents($filename, $type);
	}


	protected function isCommand(){
		//check for command character
		$total = 0;$count = 0; $command;

		if ($this->msg != "") {
			$str = explode(" ", $this->msg);
			$total = count($str);
		}
		
		if ($total == 1) {
			if ($this->msg[0] === '#' && $this->msg[1] === '#') {
				$this->argument = ltrim($this->msg, "##");
				return true;
			}
			else{
				return false;
			}
			
		  }
		elseif($total > 1)
		{
			foreach ($str as  $value) {
				if ($value[0] == '#' && $value[1] == '#') {
					$count = 1;
					$command = ltrim($value, "##");
				}
			}

			if ($count != 0) {
				$this->argument = $command;
				return true;
			  }
			  else{
			  	return false;
			  }
		}
		else
		{
			return false;
		}

	}

	protected function isGreeting(){
		//check the message if its just greetings
		// get greetings file for greeting words
		$found = 0;
		if ($this->checkCompliment($this->msg)) {
			$found += 1;
		}
		else
		{
			$grt = $this->tempFileData;
			$gWord = explode(" ", $this->msg);
			
			foreach ($gWord as $msg) {
				foreach ($grt as $key => $value) {
					if ($msg == $key) {
						$found += 1;
					}
				}	
			}
		}
		
		if ($found != 0) {
				$this->compliment = $this->getCompliment($this->msg);
				return true;

			}
			else {
				return false;
			}

	}


	protected function isRequest(){
			$msg = $this->msg;
			
			return true;	
	}

	protected function checkCompliment($msg)
	{
		$compliment = $this->getData("compliment.json");
		$this->tempFileData = $compliment;
		$totalComp = count($compliment);
		$greetings = array_keys($compliment);
		$percentComp = 0;
		for ($i=0; $i < $totalComp; $i++) { 
			similar_text($msg,$greetings[$i],$percent);
			if ($percent > $percentComp) {
				$percentComp = $percent;
				$this->compliment = $compliment[$greetings[$i]];
				//echo $percent."<br>";
				//echo $compliment[$greetings[$i]];
			}
		}

		if ($percentComp < 60) {
			return false;
		}
		else
		{
			return true;
		}
	}

	protected function getCompliment()
	{
		return $this->compliment;
	}

	protected function getData($filename){

		if (file_exists($filename)) {
			@$getdata = file_get_contents($filename);

			//Convert the JSON string back into an array.
			$data = json_decode($getdata, true);
			return $data; //return array
		}
		else
		{
			return "";
		}
		
			
	}
	protected function getData2($filename){
			if (file_exists($filename)) {
				# code...
				$data = file_get_contents($filename);
		        return $data; //return array
			}
			else{ return "";}
	}

	protected  function check_inputCharacter($data){
	/*$data= trim($data);
	$data= stripslashes($data);
	$data= htmlspecialchars($data);*/
	return $data;
	}

}
?>