<?php

class contact extends controller
{
	public function index()
 		{
 			echo "contact/index";
 		}
 		public function test()
 		{
 			echo "contact/test";
 		}
}
