<?php
/**
 * 
 */
require 'intent2.php';

class mywork extends intent
{
	
	function __construct()
	{
		# code...
	}
	function rewrite($v)
	{
		$d = $this->add();
		$r = $d."you said ".$v;
		return $r;
	}
}


?>