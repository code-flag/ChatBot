<?php

class FileStore{
	
// this function categories file from system for use
function getCategory(){
	//return category with entity array
	//Retrieve the data from our text file.
	$fileContents = file_get_contents('class.txt');

	//Convert the JSON string back into an array.
	$decoded = json_decode($fileContents, true);
	return $decoded; //return the array file
} 


function pushEntity($entity){
	// decode it array from json
	// merge entity array
	
	$cat_array = getCategory();
	//$totalClass = count($cat_array); 

	//change case to small letter
	$cat_array = array_change_key_case($cat_array);
	//get the keys for all the class
	$classKeys = array_keys($cat_array);
	// get the arrays keys for entities on each class;

	$totalClassKeys = count($classKeys);

	// add entity to entities list
	for ($i=0; $i < $totalClassKeys; $i++) { 
		# code...
		$className = $classKeys[$i]; // get class name from arraykey
		//$entityKeys = array_keys($cat_entity[$className]);
		//$TotalEntityKeys = count($entityKeys);
		//$cat_entity = array_merge($cat_entity, $class);
		$cat_arr = array_merge($cat_array[$className], $entity);
		$cat_array = array_replace($cat_array[$className], $cat_arr);
		echo "<br> <br>";
		print_r($cat_arr);
		echo "<br> <br>";
		print_r($cat_array);

	}
	//$cat_entity['school'] = array_merge($cat_entity['school'], $entity);

	$encodedString = json_encode($cat_array);

	//Save the JSON string to a text file.
	file_put_contents('class.txt', $encodedString);
	file_put_contents('entity.txt', $entity);

}

/*
	@var text string is parse to the function and save it or append it to
	previous stop words in a file
*/
function pushStopWord($word){

	$w = 0;
	$stopW = getStopWord(); // get saved stopwords 
	//echo "<br> <br> this is it ".$stopW."<br>";
	$len = str_word_count($word); //count the parsed words
	
	if ($len == 1) {  // if is just a word run this loop
		# code...
		array_push($stopW, $word);
		$w = 1;
	}
	elseif ($len > 1){
		$sWord = explode(" ", $word);
		//array_push($stopW, $sWord);
		$stopW = array_merge($stopW, $sWord);
		$w = 1;
		echo "okay";
	}
	

	if ($w == 1) {
		# code...
		$encodedString = json_encode($stopW);

		//Save the JSON string to a text file.
		file_put_contents('stopWords.txt', $encodedString);
		$w = 0;
	}

	
	
}



function displayCategory()
{
	//change case to small letter
	$cat_entity = getCategory();
	$cat_entity = array_change_key_case($cat_entity);

	$classKeys = array_keys($cat_entity);
	$entityKeys = array_keys($cat_entity['school']);

	$TotalClassKeys = count($classKeys); //entity in row
	$TotalEntityKeys = count($entityKeys); //class in column

	echo "<br> Total class = $TotalClassKeys";
	echo "<br> Total entities = $TotalEntityKeys <br>";

	for ($i=0; $i < $TotalClassKeys; $i++) { 
		# code...
		$className = $classKeys[$i];
		echo "Entity => ".$className." <br> "; 

		for ($j=0; $j < $TotalEntityKeys ; $j++) { 
			# code...
			$entityName = $entityKeys[$j];

			echo "entity name = ".$entityName."=> value =>".$cat_entity[$className][$entityName];
			echo "<br>";
		}
		
	}


}


function textToPhrase()
{
	$phraseArr = getPhrase();
	$phrase = array_push($phraseArr, $this->text);

	file_put_contents('phrase.txt', $phrase);
}





}