<?php

require_once 'chatFile.php';
	/**
	 * 
	 */
	class chats extends chatFile
	{
		
		function __construct($time, $owner, $msg)
		{
			$this->newMsg = $msg;
			$this->msgOwner = $owner ;
			$this->msgTime = $time ;
			$this->chatData = $this->getChatFile("chats.json");

		}

		public function setData($time, $owner, $msg)
		{
			$this->newMsg = $msg;
			$this->msgOwner = $owner ;
			$this->msgTime = $time ;
			$this->chatData = $this->getChatFile("chats.json");
		}

		public function readChat()
		{
			
				$filename = "chats.json";
			   $chats = $this->chatData;
			$totalMsg = count($chats);
			$tim = 0; //"Time"
			foreach ($chats as $keys => $value) {
				if ($value[0] == 0) {
					echo "<div class='space'>
						<div class='r-msg'>$value[1]</div>
					</div>";
				}
				else if ($value[0] == 1) {
					echo "<div class='space'>
						<div class='l-msg'><img src='../../../public/assets/img/profile-pic.jpg'>$value[1]</div>
					</div>";
				}
			}
			
/*
			for ($i=0; $i <$totalMsg ; $i++) { 
				if ($chats[$i][1] == 0) {
					$msg = $chats[$i][2];
					echo "<div class='space'>
						<div class='r-msg'>$msg</div>
					</div>";
				}
				else if ($chats[$i][1] == 1) {
					$msg = $chats[$i][2];
					echo "<div class='space'>
						<div class='l-msg'>$msg</div>
					</div>";
				}
			}*/

		}

		public function writeChat()
		{
			$this->saveChatFile();
		}

	}



?>