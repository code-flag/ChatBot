<?php
 	class Home extends controller
 	{
 		public function index($name ='')
 		{
 			$name ='';
 			$user = $this->model('User');
 			$user->name = $name;
 			
 			$view = $this->Views('home/index', $user->name);
 		}

 		public function index2($name ='')
 		{
 			$user = $this->model('User');
 			$user->name = $name;
 			
 			$view = $this->Views('home/Baze University, Abuja. Nigeria',['name' => $user->name ]);
 		}
 		
 	}
?>