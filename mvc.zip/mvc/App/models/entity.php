<?php
	/**
	 * 
	 */
	class Entity extends AnotherClass
	{
		
		function __construct(argument)
		{
			# code...
		}
		protected function getEntity() {

		}
		protected function getModel() {

		}
		protected function dialogTracker() {
			//get the trend of the conversation and can remember previous discussion?
		}
	}
?>