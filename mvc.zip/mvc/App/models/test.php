<?php

require 'Model\fileOrigin.php';

echo "<br>";
$cat_entity = array(
					'School' =>array(
						'school' => 1, 
						'admission' => 0, 
						'department' => 0, 
						'registration' => 0, 
						'hostel' => 0, 
						'exam' => 1
					) , 
					'department' =>array(
						'school' => 1, 
						'admission' => 0, 
						'department' => 1, 
						'registration' => 1, 
						'hostel' => 0, 
						'exam' => 0
					) ,
					'Admission' =>array(
						'school' => 1, 
						'admission' => 0, 
						'department' => 1, 
						'registration' => 1, 
						'hostel' => 0, 
						'exam' => 0
					)  
				);


$synonyms = array(
	'd' => "the",
	'u' => "you",
	'ur' => "your",
	'dat' => "that",
	'4' => "for",
	'2' => "to",
	'yeah' => "yes",
	'yea' => "yes",
	'nd' => "and",
	'n' => "and",
	'nt' => "not",
	'dd' => "did",
	'brb' => "be right back",
	'luv' => "love",
	'grt' => "great",
	'pls' => "please",
	'thnks' => "thanks",
	'tanks' => "thanks",
	'tank' => "thank",
	'bt' => "but",
	'2u' => "to you",
	'dnt' => "don't",
	'dt' => "that",
	'cnt' => "can't",

	'students' => "student",
	'studnt' => "student",
	'hotel' => "hostel",
	'hostel' => "hostel",
	'academics' => "academic",
	'acada' => "academics",
	'sch' => "school",
	'skul' => "school",
	'admissions' => "admission",
	'admision' => "admission",
	'admisions' => "admission",
	'admition' => "admission",
	'info' => "information",
	'issues' => "issue",
	'prob' => "problem",
	'accoding' => "according",
	'moni' => "morning",
	'morng' => "morning",
	'msg' => "message",
	'am' => "morning",
	'pm' => "evening",
	'frnd' => "friend",
	'frd' => "friend"



);

$arr = array('i want to' => "i want to do what",
		'i want' => "what can do for you dear",
		'i want to' => "",
		'i want you' => "",
		'i have a' => "",
		'i have issue' => "",
		'i need your help' => "",
		'what can i' => "",
		'what do you mean' => "",
		'what is' => "",
		'what are the' => "",
		'what time' => "",
		'what can i do' => "",
		'how' => "",
		'how to' => "",
		'how can i' => "",
		'how can we' => "",
		'how many' => "",
		'how many time' => "",
		'how do i' => "",
		'how do you' => "",
		'how do we' => "",
		'how will' => "",
		'how will i' => "",
		'how will you' => "",
		'how will it' => "",
		'the information' => "",
		'the issue' => "",
		'the best' => "",
		'time table' => "",
		'can i' => "",
		'can you' => "",
		'do you' => "",
		'do i' => "",
		'maybe' => "",
		'probably' => "",
		'possibly' => "",
		'possible' => "",
		'why can\'t you' => "",
		'why can\'t we' => "",
		'why can\'t i' => "",
		'according to' => "",
		'help me with' => "", 	
		'can you tell' => "", 	
		'can you explain' => "", 
		'can you guide' => "",   
		'can you help me' => "", 
		'Hey fahad' => "",    
		'hey friend' => "",
		'hey chatbot how' => "", 
		'please' => "",
		'please can you' => "",
		'please can i' => "",
		'hi' => "",
		'hey' => "",
		'hello' => "",
		'good morning' => "",
		'good evening' => "",
		'good day' => "",
		'good afternoon' => "",
		'hello sir' => "I am not sir, kindly call me fahad",
		'hello ma' => "I am not ma, kindly call me fahad",
		'good to hear' => "",
		'good to see' => "",
		'how fa' => "",
		'how your side' => "",
		'' => "",


	);
 	echo $arr['hello sir']."<br>";
echo "<br>";


//The end result.	
//var_dump($decoded);

//change case to small letter
$cat_entity = getCategory();
$cat_entity = array_change_key_case($cat_entity);

$classKeys = array_keys($cat_entity);
$entityKeys = array_keys($cat_entity['school']);

$TotalClassKeys = count($classKeys); //entity in row
$TotalEntityKeys = count($entityKeys); //class in column

echo "<br> Total class = $TotalClassKeys";
echo "<br> Total entities = $TotalEntityKeys <br>";

for ($i=0; $i < $TotalClassKeys; $i++) { 
	# code...
	$className = $classKeys[$i];
	echo "Class => ".$className." <br> "; 

	for ($j=0; $j < $TotalEntityKeys ; $j++) { 
		# code...
		$entityName = $entityKeys[$j];

		echo "entity name = ".$entityName."=> value =>".$cat_entity[$className][$entityName];
		echo "<br>";
	}
	
}



// add class to category
/*$class = array('Hostel' => array(
					'bold' => 2, 
					'monm' => 2
					)
				);*/
//$cat_entity = array_merge($cat_entity, $class);
print_r($cat_entity);

$addEnt = array('bold' => 2, 'monm' => 2);

//pushEntity($addEnt);
/*$t = "wonderful";

pushStopWord($t);

print_r(getStopWord());*/

//echo "<br> <br> memory used is ".memory_get_usage();

/*
	@var []... an array variable is parse to this function 
	and it get the new entity save and append to the file
*/
function pushEntity($entity = []){
	// decode it array from json
	// merge entity array
	
	$cat_array = getCategory();
	//$totalClass = count($cat_array); 

	//change case to small letter
	$cat_array = array_change_key_case($cat_array);
	//get the keys for all the class
	$classKeys = array_keys($cat_array);
	// get the arrays keys for entities on each class;

	$totalClassKeys = count($classKeys);

	// add entity to entities list
	for ($i=0; $i < $totalClassKeys; $i++) { 
		# code...
		$className = $classKeys[$i]; // get class name from arraykey
		//$entityKeys = array_keys($cat_entity[$className]);
		//$TotalEntityKeys = count($entityKeys);
		//$cat_entity = array_merge($cat_entity, $class);
		$cat_arr = array_merge($cat_array[$className], $entity);
		$cat_array = array_push($cat_array[$className], $cat_arr);
		echo "<br> <br>";
		print_r($cat_arr);
		echo "<br> <br>";
		print_r($cat_array);

	}
	//$cat_entity['school'] = array_merge($cat_entity['school'], $entity);

	//$encodedString = json_encode($cat_array);

	//Save the JSON string to a text file.
	//file_put_contents('entitty.txt', $encodedString);

}

/*
	@var text string is parse to the function and save it or append it to
	previous stop words in a file
*/
function pushStopWord($word){

	$w = 0;
	$stopW = getStopWord(); // get saved stopwords 
	//echo "<br> <br> this is it ".$stopW."<br>";
	$len = str_word_count($word); //count the parsed words
	
	if ($len == 1) {  // if is just a word run this loop
		# code...
		array_push($stopW, $word);
		$w = 1;
	}
	elseif ($len > 1){
		$sWord = explode(" ", $word);
		//array_push($stopW, $sWord);
		$stopW = array_merge($stopW, $sWord);
		$w = 1;
		echo "okay";
	}
	

	if ($w == 1) {
		# code...
		$encodedString = json_encode($stopW);

		//Save the JSON string to a text file.
		file_put_contents('stopWords.txt', $encodedString);
		$w = 0;
	}

	
	
}


/*function getTextEntity($entity, $len = 1)
{
	//convert entity to array
	$entVal = array();
	if ($len < 1) {
		$entVal = $entity;
	}
	else{
		$entVal = explode(" ", $entity);
		$entVal = array_merge($entVal);
	}

	return $entVal;
}*/

function pushClass($class, $entity)
{
	// merge new class to existing file of array
}


/*
	@var text is convert to array of words
*/
function textToArray($text)
{
	//$arr_val = implode(glue, pieces);
	$arr_val = explode(" ", $text); // convert each text to array seperated by ','
	//$arrNo = count($arr_val);
	//array_push($arr_val, "now");
	//echo "<br> text word count = $arrNo <br> ";
	//print_r($arr_val);

	return $arr_val;
}

function convertTo2Darray($text)
{
	
}

// this function categories file from system for use
function getCategory(){
	//return category with entity array
	//Retrieve the data from our text file.
	$fileContents = file_get_contents('json_array.txt');

	//Convert the JSON string back into an array.
	$decoded = json_decode($fileContents, true);
	return $decoded; //return the array file
} 

// this function get the stop words from system and return it as array
function getStopWord(){
	$fileContents = file_get_contents('stopWord.json');
	//Convert the JSON string back into an array.
	$stopWord = json_decode($fileContents, true);
	//this is use if the text is not in json file
	//$stopWord = explode(",", $fileContents);

	return $stopWord;
}

function p_A(){
	/*
		this function return the propability of A event ocurring in the class. Or an entity is found in a class.
	*/
}

function p_B(){
	/*
		this function return the propability of B event ocurring in the class. Or an entity is found in a class.
	*/
}

	function nEntity($ent){
		$val = count($ent);
		return $val;
	}
	function totalEntity($ent){
		$val = count($ent);
		return $val;
	}
	function compareClassEntity(){

	}
	function askClassQuestion(){

	}

function p_CE(){
	//$pE = nEntity()/totalEntity($)
}
function p_BA(){

}



class Base {
static function Show() {
echo __FILE__.'('.__LINE__.'):'.__METHOD__."\n";
}
}
class Abject extends Base{
static function Use() {
Self::Show();
Parent::Show();
}
static function Show() {
echo __FILE__.'('.__LINE__.'):'.__METHOD__."\n";
}
}

//$h = new Abject();
//$h->Use();


/*
	total entity =  30
	yes 			No
	(1) 			(0)

	no of yes = 
	no of No = 

*/

	$tm = time();
				$h = date("g",$tm); 
						$d = date("i",$tm);
						$s = date("s",$tm);
						$th =  12 - $h;
					    $tmin =  60 - $d;
					    $ts =  60 -  $s;
						$time = $th."hrs :".$d."min :".$s."sec";

						echo "<br> <br> $time";

	$phrase = new FileOrigin();
	$phrase->createClassFile();
	function getClassFaq($text)
	{
		$text=lematize($text);
		$t_phrase = getTextPhrase($text);
		$t_entity = tokenize($text);
		$t_Phrase_count = count($t_entity);

		$filename = "classFile.json";
		$data = getData($filename);
		 $totaldata = count($data);
		 $dataPhrase = array_keys($data); // get phrase
		 $prevEnt= 0 ; $classNo = 0;

		 

		 	for ($k=0; $k < $totaldata ; $k++) {  // loop for entity.. no of data phrase

		 		if ($t_phrase == $dataPhrase[$k]) {  //check phrase
		 				$dataEntity = array_keys($data[$dataPhrase[$k]]); // get entity in 2nd array
		 				$dataPhraseEnt = count($dataEntity);

		 			for ($i=0; $i <$dataPhraseEnt ; $i++) { 
		 				$entity = explode(" ", $dataEntity[$i] );  //convert file entity to array
			 			$val = findEnt($t_entity, $entity);
			 			if ($prevEnt < $val) {
			 				$prevEnt = $val;
			 				$classNo = $i;
			 			}
			 			
		 			}

		 			//echo "<br> this is it <br>".$data[$dataPhrase[$k]][$dataEntity[$classNo]]."<br>";
		 			return $data[$dataPhrase[$k]][$dataEntity[$classNo]];
		 		}
		 	}

	}

	function findEnt($textEnt, $fileEnt)
	{
		$k = count($textEnt);
		$j = count($fileEnt);
		$found = 0;

		for ($i=0; $i < $k; $i++) { 
			for ($m=0; $m < $j ; $m++) { 
				if ($textEnt[$i] == $fileEnt[$m]) {
					$found = $found + 1;
				}

			}
		}
		$occurence = $found;
		$found= 0;
		return $occurence ;

	}


	function getData($filename){
		$getdata = file_get_contents($filename);

		//Convert the JSON string back into an array.
		$data = json_decode($getdata, true);
		return $data; //return array
	}

	function getTextPhrase($text)
	{
		
		$phrase = getPhrase();
		$totalPhrase = count($phrase);
		//var_dump($phrase);
		//convert the text to array of word
		$totalword = str_word_count($text);  // count the word
		$textW = explode(" ", $text);  // convert to array or words
		$textWord =""; $textPhrase=""; $ct = 0;

		$prevPhraseNo = 0; $foundp = false;

			for ($k=0; $k < $totalPhrase ; $k++) { 
				
				/*
					this loop check if phrase is in a text and if found it get the entity
				*/

				$strC = substr_count($text,$phrase[$k]);
				//echo "<br> found <br> $strC and ct is $ct <br>";
				$pw1 = count(explode(" ", $phrase[$k]));
				
				
				//$pw2 = count(explode(" ", $phrase[$k-1]));
				if($k != 0  && $strC != 0 && $strC >= $ct  && $ct != 0){
					$pw2 = count(explode(" ", $phrase[$prevPhraseNo]));
					if ($pw1 > $pw2 ) {
						# code...
						$textPhrase = $phrase[$k];
						$prevPhraseNo = $k;
						$ct = $strC;
						echo "<br>value $phrase[$k] is = $pw1 and $pw2 <br>";
					}
					
				}
				else if(($k == 0 || $ct >= 0) && $strC > 0){
					$ct = $strC ;
					if ($ct > 0) {
						$textPhrase = $phrase[$k];
						$prevPhraseNo = $k;
					}
				}
			}
		
		return $textPhrase;
	}


	function getPhrase()
	{
		$getPhras = file_get_contents('phrase.txt');
		$phrase = explode(",", $getPhras); // convert the return string to array
		return $phrase; //return array
	}


	function tokenize($msg){
	// remove stopwords
	// remove characters
	// return aray

	$msg = check_inputCharacter($msg);
	$stopW = getStopWord();
	$stopWCount = count($stopW);
	//$textCount = str_word_count($msg);  // get the total number of word in text
	$text =  explode(" ", $msg);	// convert the text to arary of word
	$textCount = count($text);
	try {
			for ($m=0; $m < $textCount ; $m++) { 
				for ($n=0; $n <$stopWCount ; $n++) { 
					if($text[$m] == $stopW[$n] )
					{
						$text[$m] = " ";
					}
				}
		}
	} catch (Exception $e) {
		echo "$e";
	}
	
	return $text;
	// $text = implode($text, " "); // convert to string
	// echo "$text";
}

 function check_inputCharacter($data){
	$data= stripslashes($data);
	$data= filter_var($data, FILTER_SANITIZE_STRING);
	return $data;
	}

function rDictionary()
{
	$fileContents = file_get_contents('dictionary.json');

	//Convert the JSON string back into an array.
	$decoded = json_decode($fileContents, true);
	return $decoded; 
}

function lematize($msg)
	{
		
		// load dictionary
		$msg = strtolower($msg);

		$dictionary = rDictionary();
		$dictionaryKeys = array_keys($dictionary);
		$totalWords = count($dictionary);
		$textWords = str_word_count($msg);
		//$text = str_word_count($msg, 1);
		$text = explode(" ",$msg);
		//$finalText ="";

		// check by comparision the similar words
		for ($i=0; $i < $textWords ; $i++) 
		{ 
			for ($k=0; $k < $totalWords; $k++) { 
				// replace the words with expected synonyms or words
				// e.g students with student, k with okay, d with the

				//echo "$dictionaryKeys[$k]";
				if($text[$i] == $dictionaryKeys[$k]){
					$text[$i] = $dictionary[$dictionaryKeys[$k]]; // assign dictionary value
					$val = $dictionaryKeys[$k];
					//echo "found $dictionaryKeys[$k] = $dictionary[$val] <br>";
				}

			}
		}
		$text = implode($text, " ");
		$msg = $text;

		echo "$msg <br>";
		return $msg;
	}



	function getClassFaq2($text)
	{
		$text=lematize($text); // replace abbrviated words
		$t_phrase = getTextPhrase($text); // get the phrase in a text
		$t_entity = tokenize($text);      // remove all the stopwords and leave alone the entities
		$t_Phrase_count = count($t_entity); // count the number of entity found in the text

		$filename = "classFile.json";		// name of the file that holds data
		$data = getData($filename);			// get the data from directory
		 $totaldata = count($data);			// return the total number of array or row of data in the file data
		 $dataPhrase = array_keys($data); // get phrase keys: first column of the array
		 $prevEnt= 0 ;  $prevEnt2 = 0; $classNo = 0; $classNo2 = 0; $foundPval =""; $foundPval2 ="";
		 $phraseFound = false; $mainEntity=array(); $mainEntity2= array();

		 

		 	for ($k=0; $k < $totaldata ; $k++) {  // loop for no of data phrase in the row

		 		if ($t_phrase == $dataPhrase[$k]) {  //check if phrase found in the text match any of the data phrase
		 			$phraseFound = true;
		 			$foundPval = $t_phrase; // save the phrase
		 			//echo "very true";
		 				$dataEntity = array_keys($data[$dataPhrase[$k]]); // get entity keys in data array
		 				$dataPhraseEnt = count($dataEntity);

		 			for ($i=0; $i <$dataPhraseEnt ; $i++) {     //for each data array phrase
		 				$entity = explode(" ", $dataEntity[$i] );  //convert file entity to array

			 			$val = findEnt($t_entity, $entity);		// check if text entity can be found in data array entity. if found return the number of entity found
			 			if ($prevEnt < $val) {  // check if later is more than previous then there is tendency that later is more likely to be the answer
			 				$prevEnt = $val;
			 				$classNo = $i;
			 				$mainEntity = $entity; // get the main entity
			 			}
			 			
		 			}
		 			//echo "<br> this is it <br>".$data[$dataPhrase[$k]][$dataEntity[$classNo]]."<br>";
		 			// save the faq in a variable
		 			$classFaq1 = $data[$dataPhrase[$k]][$dataEntity[$classNo]];
		 		}
		 		else {
		 			// if the phrase not found in the file data phrase, then check other phrase for like entity
		 			$dataEntity = array_keys($data[$dataPhrase[$k]]); // get entity in array
		 				$dataPhraseEnt = count($dataEntity);

		 			for ($i=0; $i <$dataPhraseEnt ; $i++) { 
		 				$entity2 = explode(" ", $dataEntity[$i] );  //convert file entity to array
			 			$val2 = findEnt($t_entity, $entity2);
			 			if ($prevEnt2 < $val2) {
			 				$prevEnt2 = $val2;
			 				$classNo2 = $i;
			 				$mainEntity2 = $entity2;
			 				$foundPval2 = $dataPhrase[$k];
			 			}
			 			
		 			}

		 			$classFaq2 = $data[$dataPhrase[$k]][$dataEntity[$classNo2]];
		 		}
		 	}

		 	if ($prevEnt < $prevEnt2) { // compare the 2 phrase with highest entity comparison
		 		
		 		if ($phraseFound != false) {  // save the new entity under the new phrase if no one is found
		 			updatePhrase($data, $foundPval, $t_entity, $classFaq2);
		 		}
		 		else{							// else if phrase found
		 			$tp = count($t_entity);
		 			$dp = count($mainEntity2); 
		 			if ($tp > $dp) {			// if text entity of text is more than data phrase entity save text phrase as key
		 			updatePhrase($data, $t_phrase, $t_entity, $classFaq2);
		 			}
		 			else   			// else if text entity is less save the data under the found phrase
		 			{
		 				updatePhrase($data, $foundPval2, $t_entity, $classFaq2);
		 			}
		 		}
		 		return $classFaq2;
		 	}
		 	else  // if found phrase entity is more then run this loop
		 	{
		 		$tp = count($t_entity);
		 		$dp = count($mainEntity);
		 		if ($tp >= $dp) {
		 			updatePhrase($data, $foundPval, $t_entity, $classFaq1);
		 		}
		 		return $classFaq1;
		 	}

	}

	function updatePhrase($arr1, $phrase, $entity, $faq)
	{
		$entity = implode(" " , $entity); //convert the array entity to string 

		$arr2 = array($entity => $faq);   // convert entity to key and faq to value
		if(array_key_exists($phrase, $arr1))  // check if the phrase is existing already
		{
			$arr4 = array_merge($arr1[$phrase], $arr2);  //add the entity key with value to phrase key
			$arr4 = array_merge($arr1, array($phrase=>$arr4)); // merge the added array for new entity back to main array as value
			//replace the existing file
			//var_dump($arr4);
			$encodedString = json_encode($arr4);
			//Save the JSON string to a text file.
			//file_put_contents('classFile.json', $encodedString);
		}
		else
		{
			//array_push(array, var);
		}
		
		//var_dump($arr4);
	}


		echo "<br><br>";
	/*lematize("how gud re u in html nd css. i wt 2 tell u dat i luv them too ");

	tokenize("when will the awe@gmail.com school time table be out");*/
	//echo getTextPhrase('how can i check my result');
	$text = "i wt to check course";
	echo getClassFaq2($text);





protected function getClassFaq($text)
	{
		$classFaq1 = "";
		$classFaq2 = "";
		$prevEnt= 0 ;  $prevEnt2 = 0; $classNo = 0; $classNo2 = 0; 
		$foundPval =""; $foundPval2 ="";
		 $phraseFound = false; $mainEntity=array(); $mainEntity2= array();

		$t_phrase = $this->getTextPhrase($text); // get the phrase in a text
		$t_entity = $this->tokenize2($text);      // remove all the stopwords and leave alone the entities
		$t_Phrase_count = count($t_entity); // count the number of entity found in the text

		$filename = "classFile.json";		// name of the file that holds data
		$data = $this->getData($filename);			// get the data from directory
		if (!is_null($data)) {
			$totaldata = count($data);			// return the total number of array or row of data in the file data
		 $dataPhrase = array_keys($data); // get phrase keys: first column of the array
		 

		 

		 	for ($k=0; $k < $totaldata ; $k++) {  // loop for no of data phrase in the row

		 		if ($t_phrase == $dataPhrase[$k]) {  //check if phrase found in the text match any of the data phrase
		 			$phraseFound = true;
		 			$foundPval = $t_phrase; // save the phrase
		 			//echo "very true";
		 				$dataEntity = array_keys($data[$dataPhrase[$k]]); // get entity keys in data array
		 				$dataPhraseEnt = count($dataEntity);

		 			for ($i=0; $i <$dataPhraseEnt ; $i++) {     //for each data array phrase
		 				$entity = explode(" ", $dataEntity[$i] );  //convert file entity to array

			 			$val = $this->findEnt($t_entity, $entity);		// check if text entity can be found in data array entity. if found return the number of entity found
			 			if ($prevEnt < $val) {  // check if later is more than previous then there is tendency that later is more likely to be the answer
			 				$prevEnt = $val;
			 				$classNo = $i;
			 				$mainEntity = $entity; // get the main entity
			 			}
			 			
		 			}
		 			//echo "<br> this is it <br>".$data[$dataPhrase[$k]][$dataEntity[$classNo]]."<br>";
		 			// save the faq in a variable
		 			$classFaq1 = $data[$dataPhrase[$k]][$dataEntity[$classNo]];
		 		}
		 		else {
		 			// if the phrase not found in the file data phrase, then check other phrase for like entity
		 			$dataEntity = array_keys($data[$dataPhrase[$k]]); // get entity in array
		 				$dataPhraseEnt = count($dataEntity);

		 			for ($i=0; $i <$dataPhraseEnt ; $i++) { 
		 				$entity2 = explode(" ", $dataEntity[$i] );  //convert file entity to array
			 			$val2 = $this->findEnt($t_entity, $entity2);
			 			if ($prevEnt2 < $val2) {
			 				$prevEnt2 = $val2;
			 				$classNo2 = $i;
			 				$mainEntity2 = $entity2;
			 				$foundPval2 = $dataPhrase[$k];
			 			}
			 			
		 			}

		 			$classFaq2 = $data[$dataPhrase[$k]][$dataEntity[$classNo2]];
		 		}
		 	}

		 	if ($prevEnt < $prevEnt2) { // compare the 2 phrase with highest entity comparison
		 		
		 		if ($phraseFound != false) {  // save the new entity under the new phrase if no one is found
		 			$this->updatePhrase($data, $foundPval, $t_entity, $classFaq2);
		 		}
		 		else{							// else if phrase found
		 			$tp = count($t_entity);
		 			$dp = count($mainEntity2); 
		 			if ($tp > $dp) {			// if text entity of text is more than data phrase entity save text phrase as key
		 				$this->updatePhrase($data, $t_phrase, $t_entity, $classFaq2);
		 			}
		 			else   			// else if text entity is less save the data under the found phrase
		 			{
		 				$this->updatePhrase($data, $foundPval2, $t_entity, $classFaq2);
		 			}
		 		}
		 		return $classFaq2;
		 	}
		 	else  // if found phrase entity is more then run this loop
		 	{
		 		$tp = count($t_entity);
		 		$dp = count($mainEntity);
		 		if ($tp >= $dp) {
		 			$this->updatePhrase($data, $foundPval, $t_entity, $classFaq1);
		 		}
		 		return $classFaq1;
		 	}

		}
		else
		{
			var_dump($entity);
			$entity = implode(" " , $entity);
			echo "<br> ok ".$entity;
			$file = array($t_phrase => array("$t_entity"=>'payment'));
			$encodedString = json_encode($file);
			//Save the JSON string to a text file.
			file_put_contents('classFile.json', $encodedString);
		}
		 

	}


function csvToJson($file, $column)
{
	$csv = explode('', string)
}
function textToJson()















?>

