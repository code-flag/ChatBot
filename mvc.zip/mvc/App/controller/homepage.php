<?php
 	class Homepage extends controller
 	{
 		public function index($name ='')
 		{
 			$user = $this->model('User');
 			$user->name = $name;
 			
 			$view = $this->Views('home/Baze University, Abuja. Nigeria',['name' => $user->name ]);
 		}
 		
 	}
?>