<?php
	//require '../../models/mywork.php';

	$obj = new controller();
	$mObj = $obj->model("intent");
	$v = "";
	if (isset($_POST['reply'])) {
		
		$v = $_POST['message'];
		//echo "i see it $v";
		$vv = $mObj->listen($v);
		if ($vv == " ") {
			echo "I'm sorry i don't have answer to that";
		}

	}
	/*echo "<div class='space'>
						<div class='r-msg'>$vv</div>
					</div>";*/
;
?>

	