	var idGlobal;

			$(document).ready(function(){

				document.getElementById('p1-tab1').click();

});

			$("#myMenu #user .friend-id ").on('click', function(){
					// alert(this.id);
					idGlobal = this.id;
					var fl_id = document.getElementById(this.id);
					var a =  fl_id.getElementsByTagName("a")[0];

					document.getElementById("user-icon").innerHTML = a.innerHTML;

					$('.friend-div').hide();
					$('.chat-div').show();

					document.getElementById('message').click();

					document.getElementById('user-icon').click();


		 		});

				// fist tab js to go to chatting page
		 		$("#myMenu #friend .friend-id2 ").on('click', function(){
					// alert(this.id);
					idGlobal = this.id;
					var fl_id = document.getElementById(this.id);
					var a =  fl_id.getElementsByTagName("a")[0];

					document.getElementById("user-icon").innerHTML = a.innerHTML;

					$('.friend-div').hide();

					$('.chat-div').show();


					document.getElementById('message').click();

					document.getElementById('user-icon').click();


		 		});

				$("#back").on('click', function(){
					$('.chat-div').hide();
					$('.friend-div').show();
					document.getElementById('p1-tab1').click();
				});

				
			// this is for selection of first page tabs
		function openCity(evt, cityName) {
		    var i, tabcontent, tablinks;

		    tabcontent = document.getElementsByClassName("tabcontent");
		    for (i = 0; i < tabcontent.length; i++) {
		        tabcontent[i].style.display = "none";
		    }

		    tablinks = document.getElementsByClassName("tablinks");
		    for (i = 0; i < tablinks.length; i++) {
		        tablinks[i].className = tablinks[i].className.replace(" active", "");
		    }
		    document.getElementById(cityName).style.display = "block";
		    evt.currentTarget.className += " active";
		}

		// this is for selection of first page tabs
		function openChat(evt, cityName) {
		    var i, tabcontent, tablinks;

		    tabcontent = document.getElementsByClassName("tabcontent");
		    for (i = 0; i < tabcontent.length; i++) {
		        tabcontent[i].style.display = "none";
		    }

		    tablinks = document.getElementsByClassName("tablinks");
		    for (i = 0; i < tablinks.length; i++) {
		        tablinks[i].className = tablinks[i].className.replace(" active", "");
		    }
		    document.getElementById(cityName).style.display = "block";
		    evt.currentTarget.className += " active";
		}

		


