<?php

	/**
	 * 
	 */
	class Intent 
	{
		
		function __construct()
		{
			# code...
		}
		function add()
		{
			return "intent:";
		}
	}

?>