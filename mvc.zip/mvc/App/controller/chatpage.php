<?php

class Chatpage extends controller
 	{
 		public function index($name ='')
 		{
 			$user = $this->model('User');
 			$user->name = $name;
 			
 			$view = $this->Views('chatpage/chat',['name' => $user->name ]);
 		}
 		public function chat($name ='')
 		{
 			$user = $this->model('User');
 			$user->name = $name;
 			
 			$view = $this->Views('chatpage/chat-msg',['name' => $user->name ]);
 		}
 		
 	}

 	?>